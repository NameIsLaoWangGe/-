export module _LwgEvent {
    export enum PreLoad {

    }
    export enum Guide {

    }
    export enum Game {

    }
    export enum Task {

    }
}