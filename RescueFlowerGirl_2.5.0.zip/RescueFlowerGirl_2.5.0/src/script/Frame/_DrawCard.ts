import { Admin } from "./Lwg";

export module _DrawCard {
    export class data {

    }
    export function _init(): void {

    }
    export class DrawCardBase extends Admin._SceneBase {

    }
    export class DrawCard extends DrawCardBase {

    }
}
export default _DrawCard.DrawCard;